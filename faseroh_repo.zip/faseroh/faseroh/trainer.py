"""faseroh/trainer.py
Training loop: run_epoch (single pass) and fit (full training with
LR scheduling and checkpoint saving).
"""

import math
import time
import torch
import torch.nn as nn
import torch.optim as optim


def run_epoch(model, dl, opt, criterion, device,
              is_lstm: bool, training: bool = True, tf: float = 0.5) -> float:
    model.train() if training else model.eval()
    total = 0
    ctx   = torch.enable_grad() if training else torch.no_grad()
    with ctx:
        for src, tgt in dl:
            src, tgt = src.to(device), tgt.to(device)
            if is_lstm:
                out    = model(src, tgt, tf=tf if training else 0.0)
                logits = out[:, 1:].reshape(-1, out.shape[-1])
                labels = tgt[:, 1:].reshape(-1)
            else:
                out    = model(src, tgt[:, :-1])
                logits = out.reshape(-1, out.shape[-1])
                labels = tgt[:, 1:].reshape(-1)
            loss = criterion(logits, labels)
            if training:
                opt.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                opt.step()
            total += loss.item()
    return total / len(dl)


def fit(model, is_lstm: bool, tag: str,
        train_dl, val_dl, device, criterion,
        epochs: int = 100, ckpt_dir: str = "/tmp") -> tuple[list, list]:
    lr    = 5e-4 if is_lstm else 1e-3
    opt   = optim.Adam(
        model.parameters(), lr=lr,
        betas=(0.9, 0.999 if is_lstm else 0.98),
    )
    sched     = optim.lr_scheduler.ReduceLROnPlateau(opt, patience=8, factor=0.5, min_lr=1e-5)
    best_loss = float("inf")
    tr_log, vl_log = [], []
    t0 = time.time()

    for ep in range(1, epochs + 1):
        tf = max(0.1, 0.5 * (1 - ep / epochs))   # scheduled teacher-forcing decay
        tr = run_epoch(model, train_dl, opt, criterion, device, is_lstm, training=True,  tf=tf)
        vl = run_epoch(model, val_dl,   opt, criterion, device, is_lstm, training=False)
        sched.step(vl)
        tr_log.append(tr)
        vl_log.append(vl)

        if vl < best_loss:
            best_loss = vl
            torch.save(model.state_dict(), f"{ckpt_dir}/{tag}.pt")

        if ep % 10 == 0:
            print(f"  ep {ep:>4}/{epochs}  tr={tr:.3f}  vl={vl:.3f}  "
                  f"tf={tf:.2f}  ppl={math.exp(vl):.1f}")

    model.load_state_dict(torch.load(f"{ckpt_dir}/{tag}.pt", map_location=device))
    print(f"  done in {time.time() - t0:.0f}s  best_val={best_loss:.4f}")
    return tr_log, vl_log
