"""faseroh/dataset.py
PyTorch Dataset and collate function for Taylor seq2seq pairs.
"""

import torch
from torch.utils.data import Dataset
from torch.nn.utils.rnn import pad_sequence

from faseroh.vocab import encode


class TaylorDS(Dataset):
    def __init__(self, indices: list[int], taylor_data: list[dict],
                 t2i: dict, SOS: int, EOS: int):
        self.idx         = indices
        self.taylor_data = taylor_data
        self.t2i         = t2i
        self.SOS         = SOS
        self.EOS         = EOS

    def __len__(self):
        return len(self.idx)

    def __getitem__(self, i):
        d   = self.taylor_data[self.idx[i]]
        src = torch.tensor(encode(d["src"], self.t2i), dtype=torch.long)
        tgt = torch.tensor(
            [self.SOS] + encode(d["tgt"], self.t2i) + [self.EOS],
            dtype=torch.long,
        )
        return src, tgt


def make_collate(PAD: int):
    def collate(batch):
        srcs, tgts = zip(*batch)
        return (
            pad_sequence(srcs, batch_first=True, padding_value=PAD),
            pad_sequence(tgts, batch_first=True, padding_value=PAD),
        )
    return collate
