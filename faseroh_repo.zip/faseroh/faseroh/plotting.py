"""faseroh/plotting.py
Plotting utilities: loss curves, perplexity, chi-squared GOF histogram.
"""

import math
import matplotlib.pyplot as plt

from faseroh.metrics import chi2_gof


def plot_results(lstm_tr, lstm_vl, tf_tr, tf_vl, hist_data,
                 save_path: str = "outputs/faseroh_results.png"):
    fig, axs = plt.subplots(1, 3, figsize=(14, 4))

    # Loss curves
    axs[0].plot(range(1, len(lstm_tr)+1), lstm_tr, "#3b82f6", lw=1.5, label="LSTM train")
    axs[0].plot(range(1, len(lstm_vl)+1), lstm_vl, "#3b82f6", lw=1.5, ls="--", label="LSTM val")
    axs[0].plot(range(1, len(tf_tr)+1),   tf_tr,   "#f97316", lw=1.5, label="TF train")
    axs[0].plot(range(1, len(tf_vl)+1),   tf_vl,   "#f97316", lw=1.5, ls="--", label="TF val")
    axs[0].set(xlabel="epoch", ylabel="CE loss", title="loss")
    axs[0].legend(fontsize=8)
    axs[0].grid(alpha=0.2)

    # Perplexity
    axs[1].plot(range(1, len(lstm_vl)+1), [math.exp(l) for l in lstm_vl],
                "#3b82f6", lw=1.5, label="LSTM")
    axs[1].plot(range(1, len(tf_vl)+1),   [math.exp(l) for l in tf_vl],
                "#f97316", lw=1.5, label="TF")
    axs[1].set(xlabel="epoch", ylabel="perplexity", title="val perplexity")
    axs[1].legend(fontsize=8)
    axs[1].grid(alpha=0.2)

    # Chi-squared GOF distribution
    ratios = []
    for hd in hist_data:
        X, ndf = chi2_gof(hd["hist"], hd["expected"])
        if X and ndf and ndf > 0:
            ratios.append(X / ndf)
    axs[2].hist(ratios, bins=20, color="#64748b", edgecolor="white", alpha=0.85)
    axs[2].axvline(1.0, color="red", ls="--", lw=1.2, label="ideal=1")
    axs[2].set(xlabel="X/ndf", ylabel="count", title="χ² goodness-of-fit")
    axs[2].legend(fontsize=8)
    axs[2].grid(alpha=0.2)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"saved {save_path}")
