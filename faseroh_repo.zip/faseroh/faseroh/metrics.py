"""faseroh/metrics.py
Evaluation metrics: token accuracy, sequence accuracy (SymPy-aware),
and chi-squared goodness-of-fit.
"""

import numpy as np
import sympy as sp
import torch

from faseroh.vocab import decode


# ── Seq2seq metrics ───────────────────────────────────────────────────────────

def token_accuracy(model, dl, device, is_lstm: bool, PAD: int) -> float:
    """Fraction of non-PAD tokens predicted correctly (teacher-forced)."""
    model.eval()
    ok = n = 0
    with torch.no_grad():
        for src, tgt in dl:
            src, tgt = src.to(device), tgt.to(device)
            if is_lstm:
                out  = model(src, tgt, tf=0.0)
                pred = out[:, 1:].argmax(-1)
                ref  = tgt[:, 1:]
            else:
                out  = model(src, tgt[:, :-1])
                pred = out.argmax(-1)
                ref  = tgt[:, 1:]
            mask = ref != PAD
            ok  += (pred[mask] == ref[mask]).sum().item()
            n   += mask.sum().item()
    return ok / n if n else 0.0


def seq_accuracy(model, dl, device, i2t: dict, use_beam: bool = True) -> float:
    """
    Sequence-level accuracy using SymPy symbolic equivalence.
    Catches commutatively-equal expressions like x + x**2/2 == x**2/2 + x.
    """
    model.eval()
    ok = n = 0
    with torch.no_grad():
        for src, tgt in dl:
            src, tgt = src.to(device), tgt.to(device)
            for i in range(tgt.size(0)):
                src_i = src[i].unsqueeze(0)
                pred  = (
                    model.generate_beam(src_i, beam_width=3)
                    if use_beam and hasattr(model, "generate_beam")
                    else model.generate(src_i)
                )
                ref_str = decode(tgt[i].tolist(), i2t)
                hyp_str = decode(pred[0].tolist(), i2t)
                try:
                    ref_expr = sp.sympify(ref_str.replace(" ", ""))
                    hyp_expr = sp.sympify(hyp_str.replace(" ", ""))
                    ok += int(sp.simplify(ref_expr - hyp_expr) == 0)
                except Exception:
                    ok += 0
                n += 1
    return ok / n if n else 0.0


# ── Histogram / GOF metric ────────────────────────────────────────────────────

def chi2_gof(observed, expected, min_count: int = 5):
    """
    Section 2.3 of the paper.
    X = Σ (N_k − n_k)² / n_k
    Good fit: X/ndf ≈ 1. Bins with expected count < min_count are excluded.
    Returns (X, ndf) or (None, None) if no valid bins.
    """
    Nk   = np.array(observed, dtype=float)
    nk   = np.array(expected,  dtype=float)
    mask = nk >= min_count
    if not mask.any():
        return None, None
    X   = np.sum((Nk[mask] - nk[mask]) ** 2 / nk[mask])
    ndf = int(mask.sum())
    return float(X), ndf
