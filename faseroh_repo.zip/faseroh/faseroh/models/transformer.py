"""faseroh/models/transformer.py
Transformer seq2seq model with greedy and beam-search decoding.
"""

import math
import torch
import torch.nn as nn


class PositionalEncoding(nn.Module):
    def __init__(self, d: int, drop: float = 0.1, maxlen: int = 512):
        super().__init__()
        self.drop = nn.Dropout(drop)
        pe  = torch.zeros(maxlen, d)
        pos = torch.arange(maxlen).float().unsqueeze(1)
        div = torch.exp(torch.arange(0, d, 2).float() * (-math.log(10000.0) / d))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return self.drop(x + self.pe[:, :x.size(1)])


class TransformerSeq2Seq(nn.Module):
    def __init__(self, vsz: int, PAD: int, SOS: int, EOS: int,
                 d: int = 256, heads: int = 8,
                 enc_layers: int = 3, dec_layers: int = 3,
                 ff: int = 512, drop: float = 0.1):
        super().__init__()
        self.vsz = vsz
        self.d   = d
        self.PAD = PAD
        self.SOS = SOS
        self.EOS = EOS

        self.src_emb = nn.Embedding(vsz, d, padding_idx=PAD)
        self.tgt_emb = nn.Embedding(vsz, d, padding_idx=PAD)
        self.pe      = PositionalEncoding(d, drop)
        self.transformer = nn.Transformer(
            d, heads, enc_layers, dec_layers, ff, drop, batch_first=True
        )
        self.proj = nn.Linear(d, vsz)

    # ── masks ─────────────────────────────────────────────────────────────────
    def _pad_mask(self, t):
        return t == self.PAD

    def _causal_mask(self, sz, dev):
        return torch.triu(torch.ones(sz, sz, device=dev), diagonal=1).bool()

    # ── forward ───────────────────────────────────────────────────────────────
    def forward(self, src, tgt):
        scale = math.sqrt(self.d)
        se = self.pe(self.src_emb(src) * scale)
        te = self.pe(self.tgt_emb(tgt) * scale)
        out = self.transformer(
            se, te,
            tgt_mask                = self._causal_mask(tgt.size(1), src.device),
            src_key_padding_mask    = self._pad_mask(src),
            tgt_key_padding_mask    = self._pad_mask(tgt),
            memory_key_padding_mask = self._pad_mask(src),
        )
        return self.proj(out)

    # ── greedy decoding ───────────────────────────────────────────────────────
    @torch.no_grad()
    def generate(self, src, maxlen: int = 120):
        self.eval()
        scale = math.sqrt(self.d)
        s     = self.pe(self.src_emb(src) * scale)
        mem   = self.transformer.encoder(s, src_key_padding_mask=self._pad_mask(src))
        ys    = torch.full((src.size(0), 1), self.SOS, dtype=torch.long, device=src.device)
        for _ in range(maxlen):
            te  = self.pe(self.tgt_emb(ys) * scale)
            out = self.transformer.decoder(
                te, mem, tgt_mask=self._causal_mask(ys.size(1), src.device)
            )
            nxt = self.proj(out[:, -1]).argmax(1, keepdim=True)
            ys  = torch.cat([ys, nxt], dim=1)
            if (nxt.squeeze(1) == self.EOS).all():
                break
        return ys[:, 1:]

    # ── beam-search decoding ──────────────────────────────────────────────────
    @torch.no_grad()
    def generate_beam(self, src, beam_width: int = 3, maxlen: int = 120):
        self.eval()
        scale = math.sqrt(self.d)
        s   = self.pe(self.src_emb(src) * scale)
        mem = self.transformer.encoder(s, src_key_padding_mask=self._pad_mask(src))

        sequences = [([self.SOS], 0.0)]
        completed = []

        for _ in range(maxlen):
            all_cands = []
            for seq, score in sequences:
                if seq[-1] == self.EOS:
                    completed.append((seq, score))
                    continue
                ys  = torch.tensor(seq, device=src.device).unsqueeze(0)
                te  = self.pe(self.tgt_emb(ys) * scale)
                out = self.transformer.decoder(
                    te, mem,
                    tgt_mask=self._causal_mask(ys.size(1), src.device),
                )
                lprobs = torch.log_softmax(self.proj(out[:, -1]), dim=-1)
                topk   = torch.topk(lprobs, beam_width)
                for j in range(beam_width):
                    tok       = topk.indices[0][j].item()
                    length    = len(seq) + 1
                    new_score = (score + topk.values[0][j].item()) / (length ** 0.7)
                    all_cands.append((seq + [tok], new_score))
            if not all_cands:
                break
            sequences = sorted(all_cands, key=lambda x: x[1], reverse=True)[:beam_width]

        best = (completed or sequences)[0][0]
        return torch.tensor(best[1:], device=src.device).unsqueeze(0)
