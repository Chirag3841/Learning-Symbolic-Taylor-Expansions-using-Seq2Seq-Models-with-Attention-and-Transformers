"""faseroh/models/lstm.py
Attention-based LSTM seq2seq model with greedy and beam-search decoding.

Plain LSTM (single h,c bottleneck) fails on symbolic math — the encoder
cannot compress a 30+ token expression into one vector.
Bahdanau attention lets the decoder look at ALL encoder hidden states.
"""

import random
import torch
import torch.nn as nn


class LSTMSeq2Seq(nn.Module):
    def __init__(self, vsz: int, PAD: int, SOS: int, EOS: int,
                 emb: int = 256, hid: int = 512):
        super().__init__()
        self.vsz = vsz
        self.hid = hid
        self.PAD = PAD
        self.SOS = SOS
        self.EOS = EOS

        self.enc_emb  = nn.Embedding(vsz, emb, padding_idx=PAD)
        self.enc_rnn  = nn.LSTM(emb, hid, batch_first=True, bidirectional=True)
        self.enc_proj = nn.Linear(hid * 2, hid)
        self.dec_emb  = nn.Embedding(vsz, emb, padding_idx=PAD)
        self.dec_rnn  = nn.LSTM(emb + hid, hid, batch_first=True)
        self.attn     = nn.Linear(hid * 2, 1)
        self.proj     = nn.Linear(hid, vsz)

    # ── internal helpers ──────────────────────────────────────────────────────
    def _attend(self, dec_h, enc_out):
        dec_h_exp = dec_h.expand_as(enc_out)
        scores    = self.attn(torch.cat([dec_h_exp, enc_out], dim=-1))
        weights   = torch.softmax(scores, dim=1)
        return (weights * enc_out).sum(dim=1, keepdim=True)

    def _encode(self, src):
        enc_out, (h, _) = self.enc_rnn(self.enc_emb(src))
        enc_out = self.enc_proj(enc_out)
        h = torch.tanh(self.enc_proj(
            torch.cat([h[0], h[1]], dim=-1)
        )).unsqueeze(0)
        return enc_out, h, torch.zeros_like(h)

    # ── forward (teacher-forced training) ────────────────────────────────────
    def forward(self, src, tgt, tf: float = 0.5):
        enc_out, h, c = self._encode(src)
        B, T = tgt.shape
        outs = torch.zeros(B, T, self.vsz, device=src.device)
        tok  = tgt[:, 0]
        for step in range(1, T):
            emb     = self.dec_emb(tok.unsqueeze(1))
            context = self._attend(h.transpose(0, 1), enc_out)
            dec_in  = torch.cat([emb, context], dim=-1)
            out, (h, c) = self.dec_rnn(dec_in, (h, c))
            logits       = self.proj(out.squeeze(1))
            outs[:, step] = logits
            tok = tgt[:, step] if random.random() < tf else logits.argmax(1)
        return outs

    # ── greedy decoding ───────────────────────────────────────────────────────
    @torch.no_grad()
    def generate(self, src, maxlen: int = 120):
        self.eval()
        enc_out, h, c = self._encode(src)
        tok = torch.full((src.size(0),), self.SOS, dtype=torch.long, device=src.device)
        out = []
        for _ in range(maxlen):
            emb     = self.dec_emb(tok.unsqueeze(1))
            context = self._attend(h.transpose(0, 1), enc_out)
            e, (h, c) = self.dec_rnn(torch.cat([emb, context], dim=-1), (h, c))
            tok = self.proj(e.squeeze(1)).argmax(1)
            out.append(tok)
            if (tok == self.EOS).all():
                break
        return torch.stack(out, dim=1)

    # ── beam-search decoding ──────────────────────────────────────────────────
    @torch.no_grad()
    def generate_beam(self, src, beam_width: int = 3, maxlen: int = 120):
        self.eval()
        assert src.size(0) == 1, "beam search requires batch size 1"
        enc_out, h, c = self._encode(src)
        sequences = [([self.SOS], 0.0, h, c)]
        completed = []

        for _ in range(maxlen):
            all_cands = []
            for seq, score, h_, c_ in sequences:
                if seq[-1] == self.EOS:
                    completed.append((seq, score))
                    continue
                tok     = torch.tensor([[seq[-1]]], dtype=torch.long, device=src.device)
                emb     = self.dec_emb(tok)
                context = self._attend(h_.transpose(0, 1), enc_out)
                out, (h_new, c_new) = self.dec_rnn(
                    torch.cat([emb, context], dim=-1), (h_, c_)
                )
                lprobs = torch.log_softmax(self.proj(out.squeeze(1)), dim=-1)
                topk   = torch.topk(lprobs, beam_width)
                for j in range(beam_width):
                    tok_id    = topk.indices[0][j].item()
                    length    = len(seq) + 1
                    new_score = (score + topk.values[0][j].item()) / (length ** 0.7)
                    all_cands.append((seq + [tok_id], new_score, h_new, c_new))
            if not all_cands:
                break
            sequences = sorted(all_cands, key=lambda x: x[1], reverse=True)[:beam_width]

        best = (
            sorted(completed, key=lambda x: x[1], reverse=True)[0][0]
            if completed else sequences[0][0]
        )
        return torch.tensor(best[1:], device=src.device).unsqueeze(0)
