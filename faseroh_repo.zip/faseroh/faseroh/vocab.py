"""faseroh/vocab.py
Token-level vocabulary, encode, and decode utilities.
"""

import re

SPECIAL = ["<pad>", "<sos>", "<eos>", "<unk>"]


def tokenize(expr: str) -> list[str]:
    """Split a SymPy expression string into meaningful tokens."""
    return re.findall(r'\d+|\*\*|[a-zA-Z]+|[+\-*/()]', expr)


def build_vocab(data: list[dict]) -> tuple[dict, dict]:
    """
    Build token-to-index and index-to-token dicts from a list of
    {src, tgt} pairs. Returns (t2i, i2t).
    """
    tokens: set[str] = set()
    for d in data:
        tokens.update(tokenize(d["src"]))
        tokens.update(tokenize(d["tgt"]))
    vocab = SPECIAL + sorted(tokens)
    t2i = {tok: i for i, tok in enumerate(vocab)}
    i2t = {i: tok for tok, i in t2i.items()}
    return t2i, i2t


def encode(s: str, t2i: dict) -> list[int]:
    unk = t2i["<unk>"]
    return [t2i.get(tok, unk) for tok in tokenize(s)]


def decode(ids: list[int], i2t: dict) -> str:
    out = []
    for i in ids:
        tok = i2t.get(i, "")
        if tok == "<eos>":
            break
        if tok not in ("<pad>", "<sos>"):
            out.append(tok)
    return " ".join(out)
