"""FASEROH — Function Approximation via Seq2Seq for ROH-style Taylor expansion."""
