# Trained model checkpoints are saved here (.pt files).
# These are git-ignored — see .gitignore.
