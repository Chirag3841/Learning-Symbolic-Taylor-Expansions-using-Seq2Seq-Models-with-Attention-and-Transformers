# Plot outputs are saved here (faseroh_results.png etc.).
# These are git-ignored — see .gitignore.
