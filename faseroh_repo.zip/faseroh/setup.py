from setuptools import setup, find_packages

setup(
    name="faseroh",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "torch>=2.0",
        "sympy>=1.12",
        "scipy>=1.11",
        "numpy>=1.24",
        "matplotlib>=3.7",
        "scikit-learn>=1.3",
    ],
    python_requires=">=3.10",
)
