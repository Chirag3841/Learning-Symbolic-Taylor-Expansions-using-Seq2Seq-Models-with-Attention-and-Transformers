"""scripts/train.py
Main training script. Trains LSTM and Transformer seq2seq models on
Taylor expansion pairs, evaluates them, and saves plots.

Usage:
    python scripts/train.py
    python scripts/train.py --lstm-epochs 50 --tf-epochs 100 --device cuda
"""

import argparse
import math
import random
import warnings

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.nn.utils.rnn import pad_sequence
from sklearn.model_selection import train_test_split

from faseroh.data    import build_taylor_data, build_hist_data
from faseroh.vocab   import build_vocab, encode, decode
from faseroh.dataset import TaylorDS, make_collate
from faseroh.models  import LSTMSeq2Seq, TransformerSeq2Seq
from faseroh.trainer import fit, run_epoch
from faseroh.metrics import token_accuracy, seq_accuracy, chi2_gof
from faseroh.plotting import plot_results

warnings.filterwarnings("ignore")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--lstm-epochs", type=int, default=100)
    p.add_argument("--tf-epochs",   type=int, default=150)
    p.add_argument("--batch-size",  type=int, default=32)
    p.add_argument("--device",      type=str, default="auto")
    p.add_argument("--ckpt-dir",    type=str, default="checkpoints")
    p.add_argument("--seed",        type=int, default=42)
    return p.parse_args()


def main():
    args   = parse_args()
    device = (
        torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if args.device == "auto" else torch.device(args.device)
    )
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)

    # ── Data ──────────────────────────────────────────────────────────────────
    print("Building Taylor dataset...")
    taylor_data = build_taylor_data()
    print(f"  Taylor pairs: {len(taylor_data)}")

    print("Building histogram dataset...")
    hist_data = build_hist_data()
    print(f"  histogram samples: {len(hist_data)}")

    print("\nchi-squared GOF check (5 samples):")
    for hd in hist_data[:5]:
        X, ndf = chi2_gof(hd["hist"], hd["expected"])
        if X and ndf:
            label = "good" if 0.5 < X / ndf < 1.5 else "check"
            print(f"  X={X:.2f}  ndf={ndf}  X/ndf={X/ndf:.3f}  ({label})")

    # ── Vocab ─────────────────────────────────────────────────────────────────
    t2i, i2t = build_vocab(taylor_data)
    PAD = t2i["<pad>"]; SOS = t2i["<sos>"]; EOS = t2i["<eos>"]
    VSIZ = len(t2i)
    print(f"\nvocab size: {VSIZ}")

    # ── DataLoaders ───────────────────────────────────────────────────────────
    all_idx            = list(range(len(taylor_data)))
    tr_idx, tmp        = train_test_split(all_idx, test_size=0.2,  random_state=args.seed)
    va_idx, te_idx     = train_test_split(tmp,     test_size=0.5,  random_state=args.seed)
    print(f"train: {len(tr_idx)}  val: {len(va_idx)}  test: {len(te_idx)}")

    collate  = make_collate(PAD)
    train_dl = DataLoader(TaylorDS(tr_idx, taylor_data, t2i, SOS, EOS),
                          batch_size=args.batch_size, shuffle=True, collate_fn=collate)
    val_dl   = DataLoader(TaylorDS(va_idx, taylor_data, t2i, SOS, EOS),
                          batch_size=args.batch_size, collate_fn=collate)
    test_dl  = DataLoader(TaylorDS(te_idx, taylor_data, t2i, SOS, EOS),
                          batch_size=args.batch_size, collate_fn=collate)

    criterion = nn.CrossEntropyLoss(ignore_index=PAD)
    print(f"device={device}  vocab={VSIZ}  "
          f"lstm_epochs={args.lstm_epochs}  tf_epochs={args.tf_epochs}\n")

    # ── Train LSTM ────────────────────────────────────────────────────────────
    print("[LSTM]")
    lstm = LSTMSeq2Seq(VSIZ, PAD, SOS, EOS).to(device)
    lstm_tr, lstm_vl = fit(
        lstm, is_lstm=True, tag="lstm",
        train_dl=train_dl, val_dl=val_dl, device=device,
        criterion=criterion, epochs=args.lstm_epochs, ckpt_dir=args.ckpt_dir,
    )

    # ── Train Transformer ─────────────────────────────────────────────────────
    print("\n[Transformer]")
    tf = TransformerSeq2Seq(VSIZ, PAD, SOS, EOS, d=256, heads=8).to(device)
    tf_tr, tf_vl = fit(
        tf, is_lstm=False, tag="tf",
        train_dl=train_dl, val_dl=val_dl, device=device,
        criterion=criterion, epochs=args.tf_epochs, ckpt_dir=args.ckpt_dir,
    )

    # ── Results table ─────────────────────────────────────────────────────────
    print(f"\n{'model':14} {'split':5} {'loss':>7} {'ppl':>8} {'tok%':>7} {'seq%':>7}")
    print("-" * 52)
    for split, dl in [("val", val_dl), ("test", test_dl)]:
        for model, is_lstm, name in [(lstm, True, "LSTM"), (tf, False, "Transformer")]:
            loss = run_epoch(model, dl, None, criterion, device, is_lstm, training=False)
            tok  = token_accuracy(model, dl, device, is_lstm, PAD)
            seq  = seq_accuracy(model, dl, device, i2t, use_beam=True)
            print(f"{name:14} {split:5} {loss:7.4f} {math.exp(loss):8.2f} "
                  f"{tok*100:6.1f}% {seq*100:6.1f}%")

    # ── Sample predictions ────────────────────────────────────────────────────
    print("\nsample predictions (5 test examples):")
    _ex  = [taylor_data[i] for i in te_idx[:5]]
    _src = pad_sequence(
        [torch.tensor(encode(d["src"], t2i)) for d in _ex],
        batch_first=True, padding_value=PAD,
    ).to(device)

    for model, name in [(lstm, "LSTM"), (tf, "Transformer")]:
        preds = []
        for i in range(_src.size(0)):
            src_i = _src[i].unsqueeze(0)
            pred  = (
                model.generate_beam(src_i)
                if hasattr(model, "generate_beam") else model.generate(src_i)
            )
            preds.append(pred[0])
        print(f"\n  {name}:")
        for i, d in enumerate(_ex):
            hyp  = decode(preds[i].tolist(), i2t)
            tick = "✓" if hyp.replace(" ", "") == d["tgt"].replace(" ", "") else "✗"
            print(f"    [{tick}] {d['src']}")
            print(f"         ref: {d['tgt']}")
            print(f"         got: {hyp}")

    # ── Plot ──────────────────────────────────────────────────────────────────
    import os; os.makedirs("outputs", exist_ok=True)
    plot_results(lstm_tr, lstm_vl, tf_tr, tf_vl, hist_data)


if __name__ == "__main__":
    main()
