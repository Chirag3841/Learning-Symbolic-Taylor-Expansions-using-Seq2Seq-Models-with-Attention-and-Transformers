# FASEROH

**F**unction **A**pproximation via **SE**q2seq for **R**OH-style Taylor expansion.

Trains an LSTM (Bahdanau attention) and a Transformer to map symbolic math
expressions → their 4th-order Taylor series, then evaluates with SymPy-aware
equivalence checking and chi-squared goodness-of-fit on synthetic histogram data.

## Results

| Model       | Split | Loss   | PPL   | Token% | Seq%  |
|-------------|-------|--------|-------|--------|-------|
| LSTM        | val   | ~0.45  | ~1.6  | —      | —     |
| Transformer | val   | ~0.18  | ~1.2  | —      | —     |

*(Exact numbers depend on hardware and random seed.)*

## Repo structure

```
faseroh/
├── faseroh/                # library code
│   ├── __init__.py
│   ├── data.py             # Taylor & histogram dataset generation
│   ├── vocab.py            # tokenise / encode / decode
│   ├── dataset.py          # PyTorch Dataset + collate
│   ├── trainer.py          # run_epoch, fit
│   ├── metrics.py          # token_accuracy, seq_accuracy, chi2_gof
│   ├── plotting.py         # loss / perplexity / GOF plots
│   └── models/
│       ├── __init__.py
│       ├── lstm.py         # attention LSTM + beam search
│       └── transformer.py  # Transformer + beam search
├── scripts/
│   └── train.py            # main entry point
├── notebooks/              # exploratory Jupyter notebooks (optional)
├── outputs/                # saved plots (git-ignored)
├── checkpoints/            # saved .pt files (git-ignored)
├── requirements.txt
├── setup.py
└── .gitignore
```

## Quick start

```bash
git clone https://github.com/YOUR_USERNAME/faseroh.git
cd faseroh
pip install -e .

# train with defaults (100 LSTM epochs, 150 TF epochs)
python scripts/train.py

# custom run
python scripts/train.py --lstm-epochs 50 --tf-epochs 80 --device cuda
```

## Key design choices

- **Token-level vocab** — regex tokeniser splits on multi-char tokens like `**`, `sin`, `cos`, integers; much shorter sequences than char-level.
- **Bahdanau attention LSTM** — plain LSTM bottleneck fails on 30+ token expressions; attention over all encoder states fixes this.
- **Beam search with length penalty** — score normalised by `length^0.7` prevents short-sequence bias.
- **SymPy equivalence** — `seq_accuracy` uses `sp.simplify(ref − hyp) == 0` so `x + x**2/2` and `x**2/2 + x` both count as correct.
- **Chi-squared GOF** — histogram samples generated from random PDFs are validated with the Section 2.3 statistic `X/ndf ≈ 1`.

## Requirements

- Python 3.10+
- PyTorch 2.0+
- SymPy, SciPy, NumPy, Matplotlib, scikit-learn
