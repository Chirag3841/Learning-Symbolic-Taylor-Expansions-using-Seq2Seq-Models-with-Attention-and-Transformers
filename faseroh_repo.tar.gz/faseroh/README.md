# FASEROH

**FA**st **SE**q2seq for symbolic **R**easoning **O**n **H**istograms

Trains an LSTM (with Bahdanau attention) and a Transformer to predict the
degree-4 Maclaurin expansion of a symbolic expression — and validates the
underlying histogram dataset with a chi-squared goodness-of-fit test.

---

## Repo structure

```
faseroh/
├── src/faseroh/
│   ├── __init__.py      # public API
│   ├── data.py          # Taylor dataset + histogram PDF generation
│   ├── tokenizer.py     # tokenise / vocabulary
│   ├── dataset.py       # PyTorch Dataset & DataLoader helpers
│   ├── models.py        # LSTMSeq2Seq, TransformerSeq2Seq
│   ├── train.py         # training loop, metrics, chi-squared GOF
│   └── plot.py          # result figures
├── scripts/
│   └── train_all.py     # end-to-end training entry point
├── notebooks/           # (place Colab/Jupyter notebooks here)
├── pyproject.toml
├── requirements.txt
└── README.md
```

---

## Quick start

```bash
# 1. clone & install
git clone https://github.com/<you>/faseroh.git
cd faseroh
pip install -e ".[dev]"

# 2. train
python scripts/train_all.py
```

This will:
- generate ~3 000+ Taylor-series pairs
- build 200 random-PDF histogram samples
- train LSTM (80 epochs) and Transformer (150 epochs)
- print a results table (loss / ppl / tok-acc / seq-acc)
- save `faseroh_results.png`

---

## Key design choices

| Choice | Reason |
|---|---|
| Bahdanau attention on LSTM | Single h,c bottleneck fails on 30+ char symbolic strings |
| Bidirectional encoder | Richer context for the decoder |
| Length-normalised beam search | Prevents the model from preferring short outputs |
| Scheduled teacher-forcing decay | Bridges train/inference gap |
| ReduceLROnPlateau | Robust to noisy symbolic loss landscapes |
| χ²/ndf ≈ 1 sanity check | Validates that multinomial histogram samples match the true PDF |

---

## Requirements

- Python ≥ 3.10
- PyTorch ≥ 2.2
- SymPy, SciPy, scikit-learn, matplotlib
